plugins {
    `java-library`
}

dependencies {
    api(projects.darklafAnnotations)
}
